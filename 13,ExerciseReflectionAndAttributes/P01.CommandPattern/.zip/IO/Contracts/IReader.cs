﻿namespace P01.CommandPattern.IO.Contracts
{
    public interface IReader
    {
       string ReadLine();
    }
}
