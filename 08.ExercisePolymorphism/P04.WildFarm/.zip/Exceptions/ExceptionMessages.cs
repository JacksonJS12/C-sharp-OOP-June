﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm
{
    public class ExceptionMessages
    {
        public const string FoodNotPreffered = "{0} does not eat {1}!";
    }
}
