﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm
{
    public class Seeds : Food
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}
        