﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P04.WildFarm
{
    public interface IEngine
    {
        public void Start();
    }
}
