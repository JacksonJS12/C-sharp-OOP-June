﻿namespace Raiding.Engine
{
    public class Command
    {

        public string HeroType { get; set; }
        public string HeroName { get; set; }


    }
}
